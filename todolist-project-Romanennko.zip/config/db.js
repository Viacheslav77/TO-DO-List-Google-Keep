module.exports = {
    url: 'mongodb+srv://MaxRomanenko:max300879&@mycluster-ek997.mongodb.net/test?retryWrites=true&w=majority',
    dbName: 'database1'
};
